import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Nassau Candy Factory Optimization",page_icon="🍬",layout="wide")
df=pd.read_csv("dashboard_recommendations.csv")
cl=pd.read_csv("route_cluster_analysis.csv")

st.title("NASSAU CANDY FACTORY OPTIMIZATION SYSTEM")
st.caption("Factory reallocation and shipping optimization scenario analysis")
with st.sidebar:
    st.header("Scenario Filters")
    product=st.selectbox("Product",["All"]+sorted(df["Product Name"].unique().tolist()))
    region=st.selectbox("Region",["All"]+sorted(df["Region"].unique().tolist()))
    mode=st.selectbox("Ship Mode",["All"]+sorted(df["Ship Mode"].unique().tolist()))
    cf=st.selectbox("Current Factory",["All"]+sorted(df["Current Factory"].unique().tolist()))
    af=st.selectbox("Alternative Factory",["All"]+sorted(df["Alternative Factory"].unique().tolist()))
    speed=st.slider("Speed Priority",0,100,60,5)
    profit=100-speed
f=df.copy()
if product!="All": f=f[f["Product Name"]==product]
if region!="All": f=f[f["Region"]==region]
if mode!="All": f=f[f["Ship Mode"]==mode]
if cf!="All": f=f[f["Current Factory"]==cf]
if af!="All": f=f[f["Alternative Factory"]==af]
f=f.copy(); f["Scenario Priority Score"]=f["Lead Time Reduction (%)"]*speed/100+f["Profit Margin (%)"]*profit/100
a,b,c,d=st.columns(4)
a.metric("Scenario Records",f"{len(f):,}"); b.metric("Avg Lead-Time Reduction",f"{f['Lead Time Reduction (%)'].mean():.1f}%" if len(f) else "0%"); c.metric("Avg Distance Saving",f"{f['Distance Saving (km)'].mean():,.0f} km" if len(f) else "0 km"); d.metric("Avg Profit Margin",f"{f['Profit Margin (%)'].mean():.1f}%" if len(f) else "0%")
t1,t2,t3,t4=st.tabs(["Factory Optimization Simulator","What-If Scenario Analysis","Recommendation Dashboard","Risk & Impact Panel"])
with t1:
 st.subheader("Factory Optimization Simulator")
 st.dataframe(f.sort_values("Scenario Priority Score",ascending=False).head(25)[["Product Name","Current Factory","Alternative Factory","Region","Ship Mode","Distance Saving (km)","Distance Reduction (%)","Lead Time Saving (days)","Lead Time Reduction (%)","Profit Margin (%)","Final Recommendation Score"]],use_container_width=True,hide_index=True)
with t2:
 st.subheader("What-If Scenario Analysis")
 if len(f):
  idx=st.selectbox("Select scenario",f.head(1000).index,format_func=lambda i:f.loc[i,"Product Name"]+" | "+f.loc[i,"Current Factory"]+" → "+f.loc[i,"Alternative Factory"])
  r=f.loc[idx]; x,y,z,w=st.columns(4); x.metric("Current Distance",f"{r['Current Distance (km)']:,.0f} km"); y.metric("Alternative Distance",f"{r['Alternative Distance (km)']:,.0f} km"); z.metric("Distance Reduction",f"{r['Distance Reduction (%)']:.1f}%"); w.metric("Lead-Time Saving",f"{r['Lead Time Saving (days)']:.2f} days")
  st.bar_chart(pd.DataFrame({"Current":[r["Current Lead Time (days)"]],"Alternative":[r["Alternative Lead Time (days)"]]},index=["Lead Time (days)"]))
  st.info("Lead time is scenario-estimated from distance and ship mode assumptions, not historical observed transit time. Alternative factories are scenario candidates, not validated production assignments.")
with t3:
 st.subheader("Recommendation Dashboard")
 top=f.sort_values("Scenario Priority Score",ascending=False).head(20)
 st.dataframe(top[["Product Name","Current Factory","Alternative Factory","Lead Time Reduction (%)","Distance Reduction (%)","Profit Margin (%)","Scenario Confidence Score","Final Recommendation Score","Recommendation Level"]],use_container_width=True,hide_index=True)
 fig,ax=plt.subplots(figsize=(10,5)); q=top.head(10).sort_values("Final Recommendation Score"); ax.barh(q["Product Name"].str[:25]+" → "+q["Alternative Factory"],q["Final Recommendation Score"]); ax.set_xlabel("Final Recommendation Score"); ax.set_title("Top Scenario Candidates"); plt.tight_layout(); st.pyplot(fig)
with t4:
 st.subheader("Risk & Impact Panel")
 x,y,z=st.columns(3); x.metric("High Potential",int((f["Recommendation Level"]=="High Potential").sum())); y.metric("Moderate Potential",int((f["Recommendation Level"]=="Moderate Potential").sum())); z.metric("Filtered Coverage",f"{len(f)/len(df)*100:.1f}%")
 st.write("Profit margin is used as a stability indicator; no shipping cost-per-km or factory capacity data was supplied. Results are scenario candidates rather than confirmed reallocations.")
st.divider(); st.caption("Nassau Candy Distributor | Data Analytics & Decision Intelligence Project")
